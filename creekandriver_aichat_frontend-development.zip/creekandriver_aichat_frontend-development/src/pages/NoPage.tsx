const NoPage: React.FC = () => {
    return <h1>404</h1>;
};

export default NoPage;
