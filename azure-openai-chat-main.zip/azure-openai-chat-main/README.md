# AzureOpenAI
クリーク・アンド・リバー社向けOpenAI環境
